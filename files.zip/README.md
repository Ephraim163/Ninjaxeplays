# ENS Profile React App

This project displays information about your ENS domain (`ninjaxeplays.eth`) in a React app.

## Quick Start

1. **Install dependencies:**

   ```bash
   npm install
   ```

2. **Add your Infura project ID**

   Open `src/components/ENSProfile.js` and replace:
   ```
   const INFURA_PROJECT_ID = "YOUR_INFURA_PROJECT_ID";
   ```
   with your actual Infura project ID. [Get it free at Infura.io](https://infura.io/).

3. **Start the app:**

   ```bash
   npm start
   ```

## What does it show?

- ENS name (e.g., ninjaxeplays.eth)
- The wallet address it resolves to
- Avatar if set (via ENS records)
- Additional ENS records (email, url, description)

## Customization

- Change `ENS_NAME` in `ENSProfile.js` to use a different ENS domain.
- Add more ENS records by editing the `recordKeys` array.
- Style the component as desired.

---

## Deploy to GitHub Pages

For React apps, use [gh-pages](https://www.npmjs.com/package/gh-pages):

1. Install gh-pages:

   ```bash
   npm install --save gh-pages
   ```

2. Add these scripts to `package.json`:

   ```json
   "homepage": "https://Ephraim163.github.io/ens-profile",
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d build"
   }
   ```

3. Run:

   ```bash
   npm run deploy
   ```

---