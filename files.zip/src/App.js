import React from "react";
import ENSProfile from "./components/ENSProfile";

function App() {
  return (
    <div style={{fontFamily: "sans-serif"}}>
      <h1 style={{textAlign: "center", marginTop: "2rem"}}>ninjaxeplays.eth ENS Profile</h1>
      <ENSProfile />
    </div>
  );
}

export default App;