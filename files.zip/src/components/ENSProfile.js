import React, { useEffect, useState } from "react";
import Web3 from "web3";

const INFURA_PROJECT_ID = "YOUR_INFURA_PROJECT_ID"; // <-- Replace with your actual Infura project ID!
const ENS_NAME = "ninjaxeplays.eth";

export default function ENSProfile() {
  const [address, setAddress] = useState("");
  const [avatar, setAvatar] = useState("");
  const [records, setRecords] = useState({});

  useEffect(() => {
    async function fetchENSProfile() {
      const web3 = new Web3(`https://mainnet.infura.io/v3/${INFURA_PROJECT_ID}`);

      // Resolve ENS to address
      const resolvedAddress = await web3.eth.ens.getAddress(ENS_NAME);
      setAddress(resolvedAddress);

      // Get ENS text records (avatar, email, url, description)
      const avatarRecord = await web3.eth.ens.getText(ENS_NAME, "avatar");
      setAvatar(avatarRecord);

      const recordKeys = ["email", "url", "description"];
      const recs = {};
      for (const key of recordKeys) {
        recs[key] = await web3.eth.ens.getText(ENS_NAME, key);
      }
      setRecords(recs);
    }

    fetchENSProfile();
  }, []);

  return (
    <div style={{border: "1px solid #ccc", borderRadius: 8, padding: 24, maxWidth: 350, margin: "2rem auto", background: "#fafafa"}}>
      <h2>ENS Profile: {ENS_NAME}</h2>
      {avatar && (
        <img src={avatar} alt="ENS Avatar" style={{width: 64, height: 64, borderRadius: "50%", marginBottom: 16}} />
      )}
      <p><strong>Address:</strong> {address}</p>
      {Object.entries(records).map(([key, value]) => (
        value ? <p key={key}><strong>{key}:</strong> {value}</p> : null
      ))}
    </div>
  );
}